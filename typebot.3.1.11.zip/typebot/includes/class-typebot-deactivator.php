<?php

class Typebot_Deactivator
{
	public static function deactivate()
	{
	}
}

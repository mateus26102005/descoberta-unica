<?php

class Typebot_Activator
{
	public static function activate()
	{
	}
}
